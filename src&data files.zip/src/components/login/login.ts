import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { UserService } from '../../services/user.service';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, CommonModule, RouterLink],
  templateUrl: './login.html',
  styleUrl: './login.css',
})
export class LoginComponent {
  email: string = '';
  password: string = '';
  errorMsg: string = '';
  loading: boolean = false;

  constructor(
    private userService: UserService,
    private authService: AuthService,
    private router: Router
  ) {}

  login(): void {
    this.errorMsg = '';
    if (!this.email || !this.password) {
      this.errorMsg = 'Please enter email and password.';
      return;
    }
    this.loading = true;
    this.userService.login(this.email, this.password).subscribe({
      next: (users) => {
        this.loading = false;
        if (users.length > 0) {
          // ✅ User found → save session → go to home
          this.authService.setUser(users[0]);
          this.router.navigate(['/home']);
        } else {
          // ❌ Not found → go to signup
          this.errorMsg = 'Account not found. Redirecting to Sign Up...';
          setTimeout(() => this.router.navigate(['/signup']), 1500);
        }
      },
      error: () => {
        this.loading = false;
        this.errorMsg = 'Server error. Make sure json-server is running.';
      }
    });
  }
}
