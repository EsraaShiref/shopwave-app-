export interface ProductsResponse {}
