import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IUser } from '../modles/iuser';

@Injectable({ providedIn: 'root' })
export class UserService {

  private apiUrl = 'http://localhost:3000/users';

  constructor(private http: HttpClient) {}

  // ── READ ALL ──────────────────────────────────────────────────
  getAll(): Observable<IUser[]> {
    return this.http.get<IUser[]>(this.apiUrl);
  }

  // ── READ ONE ──────────────────────────────────────────────────
  getById(id: number): Observable<IUser> {
    return this.http.get<IUser>(`${this.apiUrl}/${id}`);
  }

  // ── CREATE (Sign Up) ─────────────────────────────────────────
  create(user: Omit<IUser, 'id'>): Observable<IUser> {
    return this.http.post<IUser>(this.apiUrl, user);
  }

  // ── UPDATE ────────────────────────────────────────────────────
  update(id: number, user: Partial<IUser>): Observable<IUser> {
    return this.http.put<IUser>(`${this.apiUrl}/${id}`, user);
  }

  // ── DELETE ────────────────────────────────────────────────────
  delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }

  
  login(email: string, password: string): Observable<IUser[]> {
    const params = new HttpParams()
      .set('email', email)
      .set('password', password);
    return this.http.get<IUser[]>(this.apiUrl, { params });
  }
}